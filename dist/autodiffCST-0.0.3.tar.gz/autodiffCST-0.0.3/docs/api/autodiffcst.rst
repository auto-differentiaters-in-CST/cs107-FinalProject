autodiffcst package
===================

Submodules
----------

autodiffcst.AD module
---------------------

.. automodule:: autodiffcst.AD
   :members:
   :undoc-members:
   :show-inheritance:

autodiffcst.skeleton module
---------------------------

.. automodule:: autodiffcst.skeleton
   :members:
   :undoc-members:
   :show-inheritance:

autodiffcst.trigmath module
---------------------------

.. automodule:: autodiffcst.trigmath
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: autodiffcst
   :members:
   :undoc-members:
   :show-inheritance:
